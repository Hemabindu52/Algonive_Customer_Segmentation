import streamlit as st
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

st.title("Customer Segmentation Dashboard")
df = pd.read_csv("clustered_customers.csv")
st.dataframe(df.head())

fig, ax = plt.subplots()
sns.scatterplot(
    x="Annual Income (k$)",
    y="Spending Score (1-100)",
    hue="Cluster",
    data=df,
    ax=ax
)
st.pyplot(fig)
