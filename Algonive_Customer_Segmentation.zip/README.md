# Customer Segmentation Using Python

Customer Segmentation project for Algonive Internship.

## Run

pip install -r requirements.txt

python customer_segmentation.py

streamlit run app.py
