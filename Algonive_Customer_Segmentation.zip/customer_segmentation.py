# Customer Segmentation Using K-Means Clustering
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.cluster import KMeans
from sklearn.preprocessing import LabelEncoder

df = pd.read_csv("dataset/Mall_Customers.csv")

le = LabelEncoder()
df["Gender"] = le.fit_transform(df["Gender"])

X = df[["Annual Income (k$)", "Spending Score (1-100)"]]

kmeans = KMeans(n_clusters=5, random_state=42, n_init=10)
df["Cluster"] = kmeans.fit_predict(X)

df.to_csv("clustered_customers.csv", index=False)
print("Completed Successfully!")
